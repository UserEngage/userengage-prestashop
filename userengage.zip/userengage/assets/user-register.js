{literal}
$(document).ready(function() {

    alert('aaa');
    
});
{/literal}